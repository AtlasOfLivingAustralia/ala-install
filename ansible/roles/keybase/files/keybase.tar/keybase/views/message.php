<?php require_once('header.php'); ?>

    <h2><?=$message; ?></h2>
    <p><?=anchor(base_url() . 'index.php/admin/', 'Log in'); ?></p>
		
<?php require_once('footer.php'); ?>