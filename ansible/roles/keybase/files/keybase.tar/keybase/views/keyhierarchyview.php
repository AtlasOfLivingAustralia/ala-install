<?php require_once('header.php');?>

<p><?=$hierarchy?></p>

<?php require_once('footer.php');?>
